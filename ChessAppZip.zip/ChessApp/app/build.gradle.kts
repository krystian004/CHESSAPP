// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    // Se non stai usando Jetpack Compose per la UI, questa riga dovrebbe essere commentata o rimossa.
    // alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.chessapp"
    compileSdk = 35 // Assicurati che questo sia l'SDK di compilazione desiderato

    defaultConfig {
        applicationId = "com.example.chessapp"
        minSdk = 27 // Il livello minimo di API supportato dalla tua app
        targetSdk = 35 // L'SDK target della tua app
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false // Imposta a true per abilitare ProGuard per la riduzione della dimensione in release
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        // Se stai usando solo layout XML e non Jetpack Compose, questa riga deve essere false o commentata.
        // Se la lasci a 'true' e non usi Compose, potrebbe causare problemi o dipendenze inutili.
        compose = false // Impostato su false per la UI basata su XML
    }
}

dependencies {
    // Dipendenze di base per un'app Android con Kotlin
    implementation("androidx.core:core-ktx:1.12.0") // Funzioni KTX per core Android
    implementation("androidx.appcompat:appcompat:1.6.1") // AppCompat per compatibilità con versioni Android precedenti
    implementation("com.google.android.material:material:1.11.0") // Material Design Components per la UI

    // Dipendenze per Activity, ViewModel e LiveData (essenziali per il pattern MVVM)
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")
    // Questa dipendenza era inclusa nel tuo file, ma in genere per Activity si usa
    // androidx.activity:activity-ktx o androidx.appcompat.app.AppCompatActivity.
    // implementation(libs.androidx.activity.compose) // Rimuossa, era legata a Compose

    // Dipendenze per i test
    testImplementation("junit:junit:4.13.2") // Unit test framework
    androidTestImplementation("androidx.test.ext:junit:1.1.5") // JUnit per test strumentati AndroidX
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1") // Espresso per UI testing

    // Commenti/Rimozioni di dipendenze Compose e Room non necessarie per il setup attuale
    // implementation(libs.androidx.core.ktx) // Duplicato, già presente sopra
    // implementation(libs.androidx.lifecycle.runtime.ktx) // Duplicato, lifecycle-viewmodel-ktx include runtime
    // implementation(platform(libs.androidx.compose.bom)) // Rimuossa, legata a Compose
    // implementation(libs.androidx.ui) // Rimuossa, legata a Compose
    // implementation(libs.androidx.ui.graphics) // Rimuossa, legata a Compose
    // implementation(libs.androidx.ui.tooling.preview) // Rimuossa, legata a Compose
    // implementation(libs.androidx.material3) // Rimuossa, legata a Compose

    // Questa dipendenza è per Room Database. Se non stai usando Room, puoi rimuoverla.
    // Se la stai usando, dovresti includere anche la libreria 'runtime'.
    // Room.compiler è solo l'annotation processor.
    // implementation(libs.androidx.room.compiler) { // Rimuossa/Commentata se non usi Room
    //     exclude(group = "org.jetbrains", module = "annotations")
    //     exclude(group = "com.intellij", module = "annotations")
    // }

    //androidTestImplementation(platform(libs.androidx.compose.bom)) // Rimuossa, legata a Compose
    //androidTestImplementation(libs.androidx.ui.test.junit4) // Rimuossa, legata a Compose
    //debugImplementation(libs.androidx.ui.tooling) // Rimuossa, legata a Compose
    //debugImplementation(libs.androidx.ui.test.manifest) // Rimuossa, legata a Compose
}