// In SquareView.kt
package com.example.chessapp.view

import android.content.Context
import android.graphics.Color
import android.widget.ImageView
import android.widget.LinearLayout
import com.example.chessapp.R // Importa R per accedere alle risorse di colore

// Non serve un'interfaccia OnSquareClickListener qui, perché il listener è impostato direttamente in MainActivity

class SquareView(context: Context, val row: Int, val col: Int) : LinearLayout(context) {

    private val pieceImageView: ImageView
    private val defaultLightColor: Int = Color.parseColor("#EEEED2") // Colore per casella chiara
    private val defaultDarkColor: Int = Color.parseColor("#769656")  // Colore per casella scura

    init {
        // Questi parametri sono già impostati dal GridLayout in MainActivity, ma è buona norma ripeterli o assicurarsi
        // che la SquareView sia configurata per riempire lo spazio.
        // layoutParams = LayoutParams(0, 0, 1f) // Questo sarà sovrascritto da GridLayout.LayoutParams
        orientation = VERTICAL
        gravity = android.view.Gravity.CENTER // Centra l'ImageView all'interno della SquareView

        // Imposta lo sfondo alternato iniziale
        updateBackgroundColor()

        // Inizializza l'ImageView per la pedina
        pieceImageView = ImageView(context).apply {
            layoutParams = LayoutParams(
                LayoutParams.MATCH_PARENT, // L'immagine occupa tutta la larghezza della casella
                LayoutParams.MATCH_PARENT  // L'immagine occupa tutta l'altezza della casella
            )
            scaleType = ImageView.ScaleType.FIT_CENTER // Scala l'immagine per adattarsi, mantenendo le proporzioni
        }
        addView(pieceImageView)

        // Abilita i clic su questa vista (già fatto in MainActivity con setOnClickListener)
        isClickable = true
        isFocusable = true
    }

    private fun updateBackgroundColor() {
        val isLightSquare = (row + col) % 2 == 0
        setBackgroundColor(if (isLightSquare) defaultLightColor else defaultDarkColor)
    }

    fun setPiece(resId: Int?) {
        if (resId != null && resId != 0) { // Controlla anche per 0, se lo usi per "no pezzo"
            pieceImageView.setImageResource(resId)
            pieceImageView.visibility = VISIBLE // Rendi visibile l'immagine se c'è un pezzo
        } else {
            pieceImageView.setImageResource(0) // Rimuovi l'immagine
            pieceImageView.visibility = INVISIBLE // O GONE, per nasconderla e non occupare spazio
        }
    }

    // NUOVO: Metodo per evidenziare la casella selezionata
    fun setHighlighted(highlight: Boolean) {
        if (highlight) {
            setBackgroundColor(context.resources.getColor(R.color.selected_square_highlight, null))
        } else {
            // Se non è più evidenziata, ripristina il colore di default
            updateBackgroundColor()
        }
    }

    // NUOVO: Metodo per evidenziare le caselle di destinazione delle mosse legali
    fun setMoveTargetHighlight(highlight: Boolean) {
        if (highlight) {
            setBackgroundColor(context.resources.getColor(R.color.possible_move_highlight, null))
        } else {
            // Se non è più evidenziata come target, ripristina il colore di default
            updateBackgroundColor()
        }
    }
}