package com.example.chessapp.data

data class Square(val row: Int, val col: Int, var piece: Piece? = null)
