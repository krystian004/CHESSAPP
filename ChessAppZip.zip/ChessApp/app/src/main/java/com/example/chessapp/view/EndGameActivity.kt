package com.example.chessapp.view

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.chessapp.R

class EndGameActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end_game)

        val winner = intent.getStringExtra("winner")
        val message = intent.getStringExtra("message")
        val player1Score = intent.getIntExtra("player1Score", 0)
        val player2Score = intent.getIntExtra("player2Score", 0)

        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        val scoreTextView = findViewById<TextView>(R.id.scoreTextView)
        val restartButton = findViewById<Button>(R.id.restartButton)

        resultTextView.text = message ?: "Partita terminata"
        scoreTextView.text = "🏁 $winner\n\nPunteggi:\n${player1Score} - ${player2Score}"

        restartButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }
}
