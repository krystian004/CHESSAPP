package com.example.chessapp.data

import kotlin.math.abs

class Board {
    val squares = Array(8) { row ->
        Array(8) { col ->
            Square(row, col)
        }
    }

    var currentPlayer: PieceColor = PieceColor.WHITE
    var enPassantTargetPosition: Position? = null

    var castlingRights: MutableMap<PieceColor, CastlingRights> = mutableMapOf(
        PieceColor.WHITE to CastlingRights(canKingSide = true, canQueenSide = true),
        PieceColor.BLACK to CastlingRights(canKingSide = true, canQueenSide = true)
    )

    var halfMoveClock: Int = 0
    var fullMoveNumber: Int = 1

    init {
        setupInitialBoard()
    }

    private fun setupInitialBoard() {
        for (col in 0 until 8) {
            squares[1][col].piece = Piece(PieceType.PAWN, PieceColor.BLACK)
            squares[6][col].piece = Piece(PieceType.PAWN, PieceColor.WHITE)
        }

        val order = listOf(
            PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
            PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
        )

        for (col in 0 until 8) {
            squares[0][col].piece = Piece(order[col], PieceColor.BLACK)
            squares[7][col].piece = Piece(order[col], PieceColor.WHITE)
        }
    }

    fun clone(): Board {
        val newBoard = Board()
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                newBoard.squares[r][c].piece = this.squares[r][c].piece?.copy()
            }
        }
        newBoard.currentPlayer = this.currentPlayer
        newBoard.enPassantTargetPosition = this.enPassantTargetPosition
        newBoard.castlingRights = mutableMapOf(
            PieceColor.WHITE to this.castlingRights[PieceColor.WHITE]!!.copy(),
            PieceColor.BLACK to this.castlingRights[PieceColor.BLACK]!!.copy()
        )
        newBoard.halfMoveClock = this.halfMoveClock
        newBoard.fullMoveNumber = this.fullMoveNumber
        return newBoard
    }

    fun getLegalMoves(from: Position): List<Position> {
        if (!isPositionValid(from)) return emptyList()
        val piece = squares[from.row][from.col].piece ?: return emptyList()
        if (piece.color != currentPlayer) return emptyList()

        val legalMoves = mutableListOf<Position>()
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val to = Position(r, c)
                if (isMoveLegal(piece, from, to)) {
                    legalMoves.add(to)
                }
            }
        }
        return legalMoves
    }

    fun isMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        if (!isPositionValid(start) || !isPositionValid(end)) return false
        if (start == end) return false

        val targetPiece = squares[end.row][end.col].piece
        if (targetPiece != null && targetPiece.color == piece.color) return false

        val isBasicMoveLegal = when (piece.type) {
            PieceType.PAWN -> isPawnMoveLegal(piece, start, end)
            PieceType.ROOK -> isRookMoveLegal(piece, start, end)
            PieceType.KNIGHT -> isKnightMoveLegal(piece, start, end)
            PieceType.BISHOP -> isBishopMoveLegal(piece, start, end)
            PieceType.QUEEN -> isQueenMoveLegal(piece, start, end)
            PieceType.KING -> isKingMoveLegal(piece, start, end)
        }

        if (!isBasicMoveLegal) return false

        // Simulo la mossa per controllare se lascia il re in scacco
        val tempBoard = this.clone()
        tempBoard.squares[end.row][end.col].piece = piece
        tempBoard.squares[start.row][start.col].piece = null

        return !tempBoard.isKingInCheck(piece.color)
    }

    fun makeMove(start: Position, end: Position) {
        if (!isPositionValid(start) || !isPositionValid(end)) return
        val pieceToMove = squares[start.row][start.col].piece ?: return
        val targetPiece = squares[end.row][end.col].piece

        // Reset en passant target (lo aggiorniamo dopo)
        enPassantTargetPosition = null

        // Gestione cattura en passant
        if (pieceToMove.type == PieceType.PAWN &&
            abs(start.col - end.col) == 1 &&
            targetPiece == null &&
            end == enPassantTargetPosition
        ) {
            val capturedPawnRow = if (pieceToMove.color == PieceColor.WHITE) end.row + 1 else end.row - 1
            if (capturedPawnRow in 0..7) {
                squares[capturedPawnRow][end.col].piece = null
            }
        }

        // Muovo il pezzo
        squares[end.row][end.col].piece = pieceToMove
        squares[start.row][start.col].piece = null

        // Imposto nuova posizione en passant se doppio passo pedone
        if (pieceToMove.type == PieceType.PAWN && abs(start.row - end.row) == 2) {
            enPassantTargetPosition = Position((start.row + end.row) / 2, start.col)
        }

        // Arrocco
        if (pieceToMove.type == PieceType.KING && abs(start.col - end.col) == 2) {
            val rookStartCol = if (end.col > start.col) 7 else 0
            val rookEndCol = if (end.col > start.col) 5 else 3
            val rook = squares[start.row][rookStartCol].piece
            squares[start.row][rookEndCol].piece = rook
            squares[start.row][rookStartCol].piece = null
        }

        // Promozione pedone a regina (semplificata)
        if (pieceToMove.type == PieceType.PAWN &&
            ((pieceToMove.color == PieceColor.WHITE && end.row == 0) ||
                    (pieceToMove.color == PieceColor.BLACK && end.row == 7))
        ) {
            squares[end.row][end.col].piece = Piece(PieceType.QUEEN, pieceToMove.color)
        }

        // Aggiorno diritti arrocco
        if (pieceToMove.type == PieceType.KING) {
            castlingRights[pieceToMove.color]?.canKingSide = false
            castlingRights[pieceToMove.color]?.canQueenSide = false
        } else if (pieceToMove.type == PieceType.ROOK) {
            if (pieceToMove.color == PieceColor.WHITE) {
                if (start == Position(7, 0)) castlingRights[PieceColor.WHITE]?.canQueenSide = false
                if (start == Position(7, 7)) castlingRights[PieceColor.WHITE]?.canKingSide = false
            } else {
                if (start == Position(0, 0)) castlingRights[PieceColor.BLACK]?.canQueenSide = false
                if (start == Position(0, 7)) castlingRights[PieceColor.BLACK]?.canKingSide = false
            }
        }

        // Aggiorno halfMoveClock
        if (pieceToMove.type == PieceType.PAWN || targetPiece != null) {
            halfMoveClock = 0
        } else {
            halfMoveClock++
        }

        // Incremento fullMoveNumber se tocca al nero
        if (currentPlayer == PieceColor.BLACK) {
            fullMoveNumber++
        }

        switchPlayer()
    }

    fun switchPlayer() {
        currentPlayer = currentPlayer.opposite()
    }

    private fun isPawnMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        val direction = if (piece.color == PieceColor.WHITE) -1 else 1
        val startRow = if (piece.color == PieceColor.WHITE) 6 else 1

        val rowDiff = end.row - start.row
        val colDiff = abs(end.col - start.col)
        val targetPiece = squares[end.row][end.col].piece

        // Movimento avanti semplice
        if (colDiff == 0 && rowDiff == direction && targetPiece == null) return true

        // Doppio passo da posizione iniziale
        if (start.row == startRow && colDiff == 0 && rowDiff == 2 * direction) {
            val intermediateRow = start.row + direction
            if (squares[intermediateRow][start.col].piece == null && targetPiece == null) return true
        }

        // Cattura diagonale
        if (colDiff == 1 && rowDiff == direction && targetPiece != null && targetPiece.color != piece.color) return true

        // En passant
        if (colDiff == 1 && rowDiff == direction && targetPiece == null && end == enPassantTargetPosition) return true

        return false
    }

    fun isRookMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        if (start.row != end.row && start.col != end.col) return false

        if (start.row == end.row) {
            if (end.col > start.col) {
                for (c in (start.col + 1) until end.col) {
                    if (squares[start.row][c].piece != null) return false
                }
            } else {
                for (c in (start.col - 1) downTo (end.col + 1)) {
                    if (squares[start.row][c].piece != null) return false
                }
            }
        } else {
            if (end.row > start.row) {
                for (r in (start.row + 1) until end.row) {
                    if (squares[r][start.col].piece != null) return false
                }
            } else {
                for (r in (start.row - 1) downTo (end.row + 1)) {
                    if (squares[r][start.col].piece != null) return false
                }
            }
        }
        return true
    }

    private fun isKnightMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        val rowDiff = abs(end.row - start.row)
        val colDiff = abs(end.col - start.col)
        return (rowDiff == 2 && colDiff == 1) || (rowDiff == 1 && colDiff == 2)
    }

    private fun isBishopMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        val rowDiff = end.row - start.row
        val colDiff = end.col - start.col
        if (abs(rowDiff) != abs(colDiff)) return false

        val rowStep = if (rowDiff > 0) 1 else -1
        val colStep = if (colDiff > 0) 1 else -1

        var r = start.row + rowStep
        var c = start.col + colStep

        while (r != end.row && c != end.col) {
            if (squares[r][c].piece != null) return false
            r += rowStep
            c += colStep
        }
        return true
    }

    fun isQueenMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        val rowDiff = abs(end.row - start.row)
        val colDiff = abs(end.col - start.col)

        return when {
            start.row == end.row || start.col == end.col -> isRookMoveLegal(piece, start, end)
            rowDiff == colDiff -> isBishopMoveLegal(piece, start, end)
            else -> false
        }
    }

    private fun isKingMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        val rowDiff = abs(end.row - start.row)
        val colDiff = abs(end.col - start.col)
        if (rowDiff <= 1 && colDiff <= 1) return true

        // Arrocco (semplificato: controlli arrocco già fatti esternamente)
        if (rowDiff == 0 && colDiff == 2) {
            val rights = castlingRights[piece.color] ?: return false
            val rookCol = if (end.col > start.col) 7 else 0
            val pathClear = if (end.col > start.col) {
                (start.col + 1 until rookCol).all { squares[start.row][it].piece == null }
            } else {
                (rookCol + 1 until start.col).all { squares[start.row][it].piece == null }
            }
            return pathClear && (if (end.col > start.col) rights.canKingSide else rights.canQueenSide)
        }

        return false
    }

    fun isKingInCheck(color: PieceColor): Boolean {
        val kingPosition = findKingPosition(color) ?: return false
        return isSquareAttacked(kingPosition, color.opposite())
    }

    private fun findKingPosition(color: PieceColor): Position? {
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val piece = squares[r][c].piece ?: continue
                if (piece.type == PieceType.KING && piece.color == color) {
                    return Position(r, c)
                }
            }
        }
        return null
    }

    // Funzione che verifica se una casella è attaccata da un colore avversario
    // Usa una versione semplificata di isBasicMoveLegal per evitare ricorsioni infinite
    fun isSquareAttacked(pos: Position, attackerColor: PieceColor): Boolean {
        for (row in 0..7) {
            for (col in 0..7) {
                val piece = squares[row][col].piece ?: continue
                if (piece.color != attackerColor) continue

                val from = Position(row, col)
                if (isBasicMoveLegal(piece, from, pos)) {
                    return true
                }
            }
        }
        return false
    }

    // Versione base, senza controlli di scacco
    private fun isBasicMoveLegal(piece: Piece, start: Position, end: Position): Boolean {
        if (!isPositionValid(start) || !isPositionValid(end)) return false
        if (start == end) return false

        val targetPiece = squares[end.row][end.col].piece
        if (targetPiece != null && targetPiece.color == piece.color) return false

        return when (piece.type) {
            PieceType.PAWN -> isPawnMoveLegal(piece, start, end)
            PieceType.ROOK -> isRookMoveLegal(piece, start, end)
            PieceType.KNIGHT -> isKnightMoveLegal(piece, start, end)
            PieceType.BISHOP -> isBishopMoveLegal(piece, start, end)
            PieceType.QUEEN -> isQueenMoveLegal(piece, start, end)
            PieceType.KING -> isKingMoveLegal(piece, start, end)
        }
    }

    private fun isPositionValid(pos: Position): Boolean {
        return pos.row in 0..7 && pos.col in 0..7
    }
    fun isCheckmate(color: PieceColor): Boolean {
        return isKingInCheck(color) && getAllLegalMoves(color).isEmpty()
    }

    fun isStalemate(color: PieceColor): Boolean {
        return !isKingInCheck(color) && getAllLegalMoves(color).isEmpty()
    }

    fun getAllLegalMoves(color: PieceColor): List<Pair<Position, Position>> {
        val allMoves = mutableListOf<Pair<Position, Position>>()
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val piece = squares[r][c].piece ?: continue
                if (piece.color != color) continue
                val from = Position(r, c)
                val moves = getLegalMoves(from)
                for (to in moves) {
                    allMoves.add(from to to)
                }
            }
        }
        return allMoves
    }

}
