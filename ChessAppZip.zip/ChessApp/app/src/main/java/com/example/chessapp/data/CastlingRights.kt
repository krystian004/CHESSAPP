package com.example.chessapp.data

data class CastlingRights(
    var canKingSide: Boolean,
    var canQueenSide: Boolean
)
