package com.example.chessapp.utils

import com.example.chessapp.R
import com.example.chessapp.data.Piece
import com.example.chessapp.data.PieceColor
import com.example.chessapp.data.PieceType
import com.example.chessapp.utils.toDrawableRes

fun Piece.toDrawableRes(): Int {
    return when (type) {
        PieceType.PAWN -> if (color == PieceColor.WHITE) R.drawable.pedina_bianca else R.drawable.pedina_nera
        PieceType.ROOK -> if (color == PieceColor.WHITE) R.drawable.torre_bianca else R.drawable.torre_nera
        PieceType.KNIGHT -> if (color == PieceColor.WHITE) R.drawable.cavallo_bianco else R.drawable.cavallo_nero
        PieceType.BISHOP -> if (color == PieceColor.WHITE) R.drawable.alfiere_bianco else R.drawable.alfiere_nero
        PieceType.QUEEN -> if (color == PieceColor.WHITE) R.drawable.regina_bianca else R.drawable.regina_nera
        PieceType.KING -> if (color == PieceColor.WHITE) R.drawable.re_bianco else R.drawable.re_nero
    }
}
