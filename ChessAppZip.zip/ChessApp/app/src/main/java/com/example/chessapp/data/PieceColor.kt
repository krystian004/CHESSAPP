// In data/PieceColor.kt
package com.example.chessapp.data

enum class PieceColor {
    WHITE, BLACK;

    fun opposite(): PieceColor {
        return if (this == WHITE) BLACK else WHITE
    }
}
