package com.example.chessapp.data

data class Position(val row: Int, val col: Int)
