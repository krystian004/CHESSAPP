// In com.example.chessapp.view/OnSquareClickListener.kt
package com.example.chessapp.view

import com.example.chessapp.data.Position // Avrai bisogno di Position anche qui

interface OnSquareClickListener {
    fun onSquareClick(position: Position)
}