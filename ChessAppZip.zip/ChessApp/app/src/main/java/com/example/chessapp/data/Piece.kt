package com.example.chessapp.data

data class Piece(val type: PieceType, val color: PieceColor)
