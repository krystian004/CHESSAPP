package com.example.chessapp.view

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.chessapp.R
import com.example.chessapp.data.*

class MainActivity : AppCompatActivity(), OnSquareClickListener {

    private lateinit var chessBoardGrid: GridLayout
    private lateinit var player1Name: String
    private lateinit var player2Name: String
    private lateinit var player1ScoreView: TextView
    private lateinit var player2ScoreView: TextView

    private val board = Board()

    private var selectedPosition: Position? = null
    private val highlightedPositions = mutableListOf<Position>()
    private var player1Score = 0
    private var player2Score = 0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chessBoardGrid = findViewById(R.id.chessBoardGrid)
        player1ScoreView = findViewById(R.id.player1Score)
        player2ScoreView = findViewById(R.id.player2Score)

        askPlayerNames()
    }

    private fun askPlayerNames() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 20)
        }
        val inputPlayer1 = EditText(this).apply { hint = "Nome giocatore 1" }
        val inputPlayer2 = EditText(this).apply { hint = "Nome giocatore 2" }

        layout.addView(inputPlayer1)
        layout.addView(inputPlayer2)

        AlertDialog.Builder(this)
            .setTitle("Inserisci nomi giocatori")
            .setView(layout)
            .setCancelable(false)
            .setPositiveButton("OK") { _, _ ->
                player1Name = inputPlayer1.text.toString().trim()
                player2Name = inputPlayer2.text.toString().trim()
                if (player1Name.isEmpty() || player2Name.isEmpty()) {
                    Toast.makeText(this, "Entrambi i nomi sono obbligatori", Toast.LENGTH_SHORT).show()
                    askPlayerNames()
                } else {
                    updateScoreUI()
                    startGame()
                }
            }
            .show()
    }

    private fun startGame() {
        setupChessBoardGrid()
    }

    private fun setupChessBoardGrid() {
        chessBoardGrid.removeAllViews()
        chessBoardGrid.rowCount = 8
        chessBoardGrid.columnCount = 8

        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val squareView = SquareView(this, row, col)
                val piece = board.squares[row][col].piece
                squareView.setPiece(piece?.let { getPieceDrawable(it) })

                val params = GridLayout.LayoutParams().apply {
                    rowSpec = GridLayout.spec(row, 1f)
                    columnSpec = GridLayout.spec(col, 1f)
                    width = 0
                    height = 0
                    setMargins(1, 1, 1, 1)
                }

                squareView.layoutParams = params
                squareView.setOnClickListener {
                    onSquareClick(Position(row, col))
                }

                chessBoardGrid.addView(squareView)
            }
        }
    }

    private fun getSquareView(position: Position): SquareView {
        val index = position.row * 8 + position.col
        return chessBoardGrid.getChildAt(index) as SquareView
    }

    private fun getPieceDrawable(piece: Piece): Int {
        return when (piece.type) {
            PieceType.PAWN -> if (piece.color == PieceColor.WHITE) R.drawable.pedina_bianca else R.drawable.pedina_nera
            PieceType.ROOK -> if (piece.color == PieceColor.WHITE) R.drawable.torre_bianca else R.drawable.torre_nera
            PieceType.KNIGHT -> if (piece.color == PieceColor.WHITE) R.drawable.cavallo_bianco else R.drawable.cavallo_nero
            PieceType.BISHOP -> if (piece.color == PieceColor.WHITE) R.drawable.alfiere_nero else R.drawable.alfiere_bianco
            PieceType.QUEEN -> if (piece.color == PieceColor.WHITE) R.drawable.regina_bianca else R.drawable.regina_nera
            PieceType.KING -> if (piece.color == PieceColor.WHITE) R.drawable.re_bianco else R.drawable.re_nero
        }
    }

    override fun onSquareClick(position: Position) {
        val clickedPiece = board.squares[position.row][position.col].piece

        if (selectedPosition == null) {
            if (clickedPiece != null && clickedPiece.color == board.currentPlayer) {
                selectedPosition = position
                highlightSelected(position)
            }
        } else {
            if (position == selectedPosition) {
                selectedPosition = null
                clearHighlights()
            } else if (highlightedPositions.contains(position)) {
                val from = selectedPosition!!
                val piece = board.squares[from.row][from.col].piece!!
                val captured = board.squares[position.row][position.col].piece
                board.makeMove(from, position)

                if (captured != null) {
                    val score = when (captured.type) {
                        PieceType.PAWN -> 1
                        PieceType.KNIGHT, PieceType.BISHOP -> 3
                        PieceType.ROOK -> 5
                        PieceType.QUEEN -> 9
                        PieceType.KING -> 100
                    }
                    if (board.currentPlayer == PieceColor.BLACK) player1Score += score else player2Score += score
                    updateScoreUI()
                }

                selectedPosition = null
                clearHighlights()
                setupChessBoardGrid()

                checkEndGameCondition()
            } else {
                if (clickedPiece != null && clickedPiece.color == board.currentPlayer) {
                    selectedPosition = position
                    highlightSelected(position)
                }
            }
        }
    }

    private fun highlightSelected(position: Position) {
        clearHighlights()
        getSquareView(position).setHighlighted(true)

        val piece = board.squares[position.row][position.col].piece ?: return
        val moves = board.getLegalMoves(position)

        for (move in moves) {
            getSquareView(move).setMoveTargetHighlight(true)
            highlightedPositions.add(move)
        }
    }

    private fun clearHighlights() {
        for (pos in highlightedPositions) {
            getSquareView(pos).setMoveTargetHighlight(false)
        }
        highlightedPositions.clear()

        selectedPosition?.let {
            getSquareView(it).setHighlighted(false)
        }
    }

    private fun updateScoreUI() {
        player1ScoreView.text = "$player1Name: $player1Score"
        player2ScoreView.text = "$player2Name: $player2Score"
    }

    private fun checkEndGameCondition() {
        val currentColor = board.currentPlayer
        val hasLegalMoves = (0..7).any { r ->
            (0..7).any { c ->
                val pos = Position(r, c)
                val piece = board.squares[r][c].piece
                piece != null && piece.color == currentColor && board.getLegalMoves(pos).isNotEmpty()
            }
        }

        if (!hasLegalMoves) {
            val inCheck = board.isKingInCheck(currentColor)
            val winner = if (currentColor == PieceColor.WHITE) player2Name else player1Name
            val result = if (inCheck) {
                "$winner ha vinto per scacco matto!"
            } else {
                "Patta per stallo!"
            }

            showEndGameScreen(winner, "$result\n\n$player1Name: $player1Score\n$player2Name: $player2Score")
        }
    }

    private fun showEndGameScreen(winner: String, message: String) {
        val intent = Intent(this, EndGameActivity::class.java).apply {
            putExtra("winner", winner)
            putExtra("message", message)
            putExtra("player1Score", player1Score)
            putExtra("player2Score", player2Score)
        }
        startActivity(intent)
        finish()
    }
}
